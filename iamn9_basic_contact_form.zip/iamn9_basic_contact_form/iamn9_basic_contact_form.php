<?php

/*
Plugin Name: Basic Contact Form by iamn9   
Plugin URI: http://iamnahid.github.io
Description: This is a simple plugin, where you can add contact form in your website.
Author: iamnahid
Version: 0.1
Author URI: http://iamnahid.github.io
*/

function iamn9_contact_form()
{
    $content = "" ;
    $content .= "<h2>Contact Us!</h2>";
    $content .= '<form method="post" action="http://localhost/wp-demo/thank-you/">';
        $content .= "<input type='text' class='form-control' placeholder='Your Name' name='name_n9'><br>";
        $content .= "<input type='text' class='form-control' placeholder='Your Mail' name='mail_n9'><br>";
        $content .= "<textarea  placeholder='Your Questions/Comments' class='form-control' name='comm_n9'></textarea><br>";
        $content .= "<input type='submit' class='button button-primary' value='Submit' name='submit_n9'>";
        
    $content .= "</form>";
    

    return $content;
}

add_shortcode('contact_formn9', 'iamn9_contact_form');

function contact_form_capture()
{
    if (isset($_POST['submit_n9']))
    {
        $name = sanitize_text_field($_POST['name_n9']);
        $email = sanitize_text_field($_POST['mail_n9']);
        $com = sanitize_textarea_field($_POST['comm_n9']);

        echo $name,$email, $com;
        $to = "iamnahid.n9@gmail.com";
        $subject = "Contact Form Plugin User Details";
        $message = $name.' - '.$email.' - '.$com;

        wp_mail($to, $subject, $message);
    }

}

add_action('wp_head','contact_form_capture');

